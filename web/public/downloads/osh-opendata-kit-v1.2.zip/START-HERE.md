# OSH 데이터 제작 키트 1.2

1. [제작 가이드](opendata/README.md)를 읽으세요.
2. opendata/_template 폴더를 새 작업 폴더로 복사하세요. 포함된 3행은 DEMO 합성 예시입니다.
3. [AI 작업 지시문](docs/OPENDATA-AI-TASK.md)의 A 블록을 채워 제작 AI에게 전달하세요.
4. 코드가 있으면 ENVIRONMENT.md와 의존성 파일을 실제 실행 결과로 채우세요.
5. 원본을 보존하고 설명·검증 결과·HANDOFF와 함께 담당자에게 전달하세요.

이 키트에는 자동 업로드 기능이 없습니다. 실제 자료 전달 경로는 담당자와 정합니다.
전체 Hub 참고 문서는 GitHub 링크로 열립니다.
